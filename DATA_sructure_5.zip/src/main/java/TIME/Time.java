package TIME;

import TotalAffair.GroupActivity;
import TotalAffair.Lesson;
import TotalAffair.PersonalActivity;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;


public class Time {
    private static int time = 0;       //默认当前时间是10点
    public static int year = 2023;
    public static int month = Time.time / (30 * 24) + 1;
    public static int day = Time.time / 24 - (Time.time / (30 * 24) * 30) + 1;
    public static int hour = Time.time % 24;
    public static Queue<Clock> qu = new PriorityQueue<>(new UserComparator1());     //优先队列，按照时间排序
    public static int getTime() {
        return time;
    }
    public static void addTime() {
        Time.time ++;
        if(Time.time % (30 * 24) == 0)
        {
            month ++;
            day = 0;
        }
        if(Time.time % 24 == 0)
        {
            day ++;
        }
        hour = Time.time % 24;
    }

    public static void addClock(Clock clock)
    {
        int flag = 0;
        System.out.println(String.format("type:%d, Name:%s, Time:%d, Cycle:%d, Interval:%d", clock.getType(), clock.getName(), clock.getTime(), clock.getCycle(), clock.getInterval()));
        switch(clock.getType())
        {
            case 1:
                if(Lesson.searchLesson(clock.getName()))
                    flag = 1;
                break;
            case 2:
                if(GroupActivity.searchGroupActivity(clock.getName()))
                    flag = 1;
                break;
            case 3:
                if(PersonalActivity.searchPersonalActivity(clock.getName()))
                    flag = 1;
                break;
            case 4:
                flag = 1;

        }
        if(flag == 0)
        {
            System.out.println("闹钟添加失败");
            return;
        }

        for(int i = 0; i < clock.getCycle(); i ++)//getCycle()是周期，比如如果是每天的话，就是1，如果是每周的话，就是7
        {
            if(clock.getTime() + i * clock.getInterval() * 24 >= Time.getTime())//
            {
                if(flag == 1)       //只有第一次添加成功才会打印
                {
                    System.out.println("闹钟添加成功");
                    flag = 0;
                }
                Clock temp = new Clock(clock.getType(), clock.getName(), clock.getTime() + i * clock.getInterval() * 24, clock.getCycle(), clock.getInterval());//getInterval()是间隔
                qu.add(temp);
            }
        }

    }
    public static int convertToInt(int mon, int day, int hour)
    {
        return (((mon - 1) * 30) + (day - 1)) * 24 + hour;
    }

}
class UserComparator1 implements Comparator<Clock> //比较器，按照时间排序
{
    public int compare(Clock p1, Clock p2) {
        return p1.getTime() - p2.getTime();
    }
}