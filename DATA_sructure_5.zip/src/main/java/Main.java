import Window.Admin;
import Window.Student_windows;
import Window.log_in;
import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;


public class Main {

    /*Admin admin = new Admin();
    Student_windows student_windows = new Student_windows();
    login_window(admin,student_windows);*/


    public static void main(String[] args)throws
            ClassNotFoundException,
            UnsupportedLookAndFeelException,
            InstantiationException,
            IllegalAccessException {

        //安装idea的浅色界面风格
        FlatDarkLaf.install();

        Admin admin = new Admin();
        Student_windows student_windows = new Student_windows();



        //Student student = new Student("xiaomin", 0);
        log_in.login_window(admin,student_windows);
//                TimeThread timeThread = new TimeThread(student);
//                timeThread.start();
//                timeThread.setSuspendFlag(true);
//                new Thread(new win_clock(timeThread)).start();
//                //打印当前线程的名称
//                System.out.println(Thread.currentThread().getName());
//
//                Scanner scanner = new Scanner(System.in);
//                while (scanner.hasNext()) {
//                    String input = scanner.next();
//                    System.out.println(input);
//                    if ("t".equals(input)) { // 暂停线程
//                        timeThread.setSuspendFlag(true);
//                    } else if ("start".equals(input)) { // 恢复线程
//                        timeThread.setSuspendFlag(false);
//                        synchronized (timeThread) {
//                            System.out.println("时间开始运行");
//                            timeThread.notify();
//                        }
//                    }
//                }
    }


}
