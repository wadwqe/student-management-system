package Stu;

public class StudentManagement {
    private Student student;
    public StudentManagement(Student student)
    {
        this.student = student;
    }
}
