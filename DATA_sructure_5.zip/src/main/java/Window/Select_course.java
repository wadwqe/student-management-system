package Window;

import Stu.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import static TotalAffair.GroupActivity.groupactivity;
import static TotalAffair.Lesson.lessonKu;
import static TotalAffair.PersonalActivity.personalactivity;
import static Window.Student_windows.student_window;

public class Select_course {
    //通过方法Select_course()创建一个窗口
    //这个窗口由student_windows.java中的选择课程按钮触发
    //在这个窗口中，会显示由管理员添加课程后的课程库，通过遍历Lessen[]数组获取课程库中的课程信息，然后将课程信息显示在窗口中，是一个列表，每个课程都有一个选择按钮，点击之后，会弹出一个对话框，询问是否选择这门课程
    //如果选择了这门课程，那么这门课程就会被添加到学生的课程表中，通过Student类中的addCourse方法实现


    //因为需要知道是哪个学生在操作，所以需要传入一个Student类的实例
    public static void Select_course_f(Student student)
    {
        JFrame frame = new JFrame("选课界面");//创建一个窗口对象
        frame.setSize(1000, 1000);//设置窗口的大小
        frame.setLocationRelativeTo(null);//设置窗口居中
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//设置窗口关闭的时候退出程序
        frame.setVisible(true);//设置窗口可见
        frame.setLayout(new BorderLayout());

        //整个窗口包含两个面板，左边面板添加列表组件，用于显示课程库中的课程信息，右边面板是学生的课表，用于显示学生已经选择的课程的信息
        //左边面板是一个滚动面板
        JSplitPane splitPane = new JSplitPane();//用于分割窗口的组件
        splitPane.setDividerLocation(200);//设置分割线的位置
        splitPane.setDividerSize(5);//设置分割线的宽度
        frame.add(splitPane, BorderLayout.CENTER);//将分割面板添加到窗口中
        JScrollPane leftPanel = new JScrollPane();//左边面板
        JPanel rightPanel = new JPanel();//右边面板


        //设置可见性
        leftPanel.setVisible(true);
        rightPanel.setVisible(true);
        //设置面板的布局方式
        leftPanel.setLayout(null);
        //设置右边面板的布局方式为流式布局
        rightPanel.setLayout(new BorderLayout());

        splitPane.setRightComponent(rightPanel);//将右边面板添加到分割面板中
        splitPane.setLeftComponent(leftPanel);//将左边面板添加到分割面板中

        String[] week = {"第一周", "第二周", "第三周", "第四周", "第五周", "第六周", "第七周", "第八周", "第九周", "第十周", "第十一周", "第十二周", "第十三周", "第十四周", "第十五周", "第十六周", "第十七周", "第十八周", "第十九周", "第二十周"};
        JComboBox<String> comboBox = new JComboBox<>(week);
        comboBox.setBounds(0, 0, 200, 50);
        comboBox.setVisible(true);
        //将下拉列表添加到右边面板的北边
//        JPanel UPpanel = new JPanel();
//        UPpanel.add(comboBox);
        rightPanel.add(comboBox, BorderLayout.NORTH);
        //新建一个面板，用于显示学生的课表
        JPanel tablePanel = new JPanel();
        //将表格面板添加到右边面板的中间
        //设置面板不可见
        tablePanel.setVisible(true);
        tablePanel.setLayout(new BorderLayout());

        rightPanel.add(tablePanel, BorderLayout.CENTER);

        JTable table = new JTable();

        //定义一个下拉列表，用于选择周数

        //获取下拉列表中的周数（Sring）,通过映射关系，获取到对应的周数(int),使用监视器，当下拉列表中的周数发生改变时，获取到对应的周数，然后将周数传入showTable(rightPanel, student, weekNum);方法中，用于显示学生的课表
        final int[] weekNum = {1};
        showTable(tablePanel, student, weekNum[0], table);
        comboBox.addItemListener(e -> //添加监视器，如果下拉列表中的周数发生改变，那么获取到对应的周数
        {
            String s = (String) comboBox.getSelectedItem();
            if (s != null) {
                switch (s) {
                    case "第一周" -> weekNum[0] = 1;
                    case "第二周" -> weekNum[0] = 2;
                    case "第三周" -> weekNum[0] = 3;
                    case "第四周" -> weekNum[0] = 4;
                    case "第五周" -> weekNum[0] = 5;
                    case "第六周" -> weekNum[0] = 6;
                    case "第七周" -> weekNum[0] = 7;
                    case "第八周" -> weekNum[0] = 8;
                    case "第九周" -> weekNum[0] = 9;
                    case "第十周" -> weekNum[0] = 10;
                    case "第十一周" -> weekNum[0] = 11;
                    case "第十二周" -> weekNum[0] = 12;
                    case "第十三周" -> weekNum[0] = 13;
                    case "第十四周" -> weekNum[0] = 14;
                    case "第十五周" -> weekNum[0] = 15;
                    case "第十六周" -> weekNum[0] = 16;
                    case "第十七周" -> weekNum[0] = 17;
                    case "第十八周" -> weekNum[0] = 18;
                    case "第十九周" -> weekNum[0] = 19;
                    case "第二十周" -> weekNum[0] = 20;
                }
            }
            //tablePanel.removeAll();
            showTable(tablePanel, student, weekNum[0], table);

        });





        //左边面板添加列表组件，用于显示课程库中的课程信息
        //列表的名称是课程库，可上下滚动
        int k = 0;
        //通过遍历lessenKu[1000]数组获取课程库中的课程信息，然后将课程信息显示在左边列表中，列表的下方有选择和退选两个按钮，点击之后，会弹出一个对话框，询问是否选择、退选这门课程
        for (int i = 0; i < 1000; i++) {

            if (lessonKu[i] != null) {
                //为每个课程创建一个按钮，鼠标悬浮在按钮上时，会显示课程的详细信息，鼠标点击按钮时，会弹出一个对话框，询问是否选择这门课程
                JButton button = new JButton(lessonKu[i].getName());
                k++;
                //设置按钮的位置和大小
                int x = 0;
                int y = k * 55;
                int width = 200;
                int height = 50;
                button.setBounds(x, y, width, height);

                button.setToolTipText("课程名称：" + lessonKu[i].getName() + "\n开始时间：" + lessonKu[i].getStartTime() + "\n结束时间：" + lessonKu[i].getEndTime() + "\n上课地点：" + lessonKu[i].getPlace() + "\n线上平台：" + lessonKu[i].getPlatform() + "\n线上链接：" + lessonKu[i].getLink() );
                //将按钮添加到左边面板中，但是按钮的位置是从上到下排列的，所以要保证第二个按钮在第一个按钮的下方，且不会覆盖第一个按钮，所以需要将按钮添加到一个面板中，然后将面板添加到左边面板中
                button.setVisible(true);

                leftPanel.add(button);
                //为每个按钮添加一个监听器，当鼠标点击按钮时，会弹出一个对话框，询问是否选择这门课程
                int finalI = i;
                int finalWeekNum = weekNum[0];
                button.addActionListener(e -> {
                    int n = JOptionPane.showConfirmDialog(null, "是否选择这门课程？", "提示", JOptionPane.YES_NO_OPTION);
                    if (n == 0) {
                        //如果选择了这门课程，那么这门课程就会被添加到学生的课程表中，通过Student类中的addAffair()方法实现
                        student.addAffair(lessonKu[finalI]);
                        //这里学生添加了课程之后，需要将课程库中的课程信息异步刷新，需要重新绘制左边面板，所以需要将左边面板中的组件全部移除，然后重新添加，这样就可以实现异步刷新

                        //重新添加组件
                        showTable(tablePanel, student, finalWeekNum, table);
                        //rightPanel.add(tablePanel, BorderLayout.CENTER);



                    }
                });

            }
        }

        //设置一个窗口关闭监听器，当窗口关闭时，会弹出一个对话框，询问是否返回学生界面
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int n = JOptionPane.showConfirmDialog(null, "是否返回学生界面？", "提示", JOptionPane.YES_NO_OPTION);
                if (n == 0) {
                    //如果选择了返回学生界面，那么就会关闭当前窗口，然后打开学生界面
                    frame.dispose();
                    student_window(student);
                }
            }
        });

    }

    //定义一个方法，用于重新显示课表
    public static void showTable(JPanel tablePanel, Student student, int week1_int,JTable table) {
        //定义表头
        String[] columnNames = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};



        //定义一个二维数组，用于存储表格中的数据，//根据下拉列表中的周数，来考虑遍历什么地方的Ctime_table[]数组，因为一周有24*7=168个小时，所以如果week1=2，那么就遍历Ctime_table[168]到Ctime_table[335]，如果week1=3，那么就遍历Ctime_table[336]到Ctime_table[503]，以此类推
        String[][] data1 = new String[24][7];
        String[][] data2 = new String[10][7];
        String[][] data3 = new String[10][7];
        //初始化data1、data2数组为0
        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                data1[i][j] = "0";
                if (i >= 8 && i <= 17) {
                    data2[i - 8][j] = "0";
                    data3[i - 8][j] = "0";
                }
            }
        }


        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                data1[i][j] = String.valueOf(student.getCtime_table()[i + j * 24 + (week1_int - 1) * 168]);
                if (i >= 8 && i <= 17) {
                    data2[i - 8][j] = data1[i][j];
                }
            }
        }

        //通过MAP映射，将data2数组中的0、1、2、3等课程id转换为对应的课程名称，映射到data3数组中

        idToName(1,data2, data3);

        //课程表中连续时间段的同一课程的多个单元格合并为一个单元格
        //MerGeCell(table, data3);




        //打印data2数组，用于测试
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 7; j++) {
                System.out.print(data2[i][j] + " ");
            }
            System.out.println();
        }
        //打印“***************”
        System.out.println("***************");


        //设置表格的模式
        table.setModel(new DefaultTableModel(data3, columnNames));
        //设置表头大小
        table.getTableHeader().setPreferredSize(new Dimension(table.getTableHeader().getWidth(), 50));
        //
        table.setRowHeight(80);


        //tablePanel.removeAll();
        //设置可见性
        tablePanel.setVisible(true);




        //将表头和表格添加到右边面板中,表头在北边，表格填充剩余空间
        tablePanel.add(table.getTableHeader(), BorderLayout.NORTH);
        tablePanel.add(table, BorderLayout.CENTER);
        table.setVisible(true);
        //tablePanel.paintImmediately(tablePanel.getBounds());

    }



    public static void idToName(int k, String[][] data2, String[][] data3) //k=1代表要处理的事务是Lesson，k=2代表要处理的事务是GroupActivity，k=3代表要处理的事务是PersonalActivity
    {
        if (k==1)
        {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 7; j++) {
                    //如果data2[i][j]不等于0，则将data3[i][j]=getLessonById(data2[i][j]).getName()
                    if (!data2[i][j].equals("0")) {
                        data3[i][j] = getLessonById(k,data2[i][j]);
                        data2[i][j] = "0";
                    }
                }
            }

        }
        else if(k==2){
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 7; j++) {
                    //如果data2[i][j]不等于0，则将data3[i][j]=getLessonById(data2[i][j]).getName()
                    if (!data2[i][j].equals("0")) {
                        data3[i][j] = getLessonById(k,data2[i][j]);
                        data2[i][j] = "0";
                    }
                }
            }

        }
        else if(k==3) {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 7; j++) {
                    //如果data2[i][j]不等于0，则将data3[i][j]=getLessonById(data2[i][j]).getName()
                    if (!data2[i][j].equals("0")) {
                        data3[i][j] = getLessonById(k, data2[i][j]);
                        data2[i][j] = "0";
                    }
                }
            }
        }


    }


    private static String getLessonById(int k, String s)
    {
        int id = Integer.parseInt(s);
        if (k==1)
        {

        //遍历课程库，找到id为s的课程，返回该课程的名称
        for (int i = 0; i < 1000; i++)
        {
            if (lessonKu[i] != null)
            if (lessonKu[i].getId()!=-1 && lessonKu[i].getId()==id)
                return lessonKu[i].getName();
        }
        return null;
        }
        else if (k==2)
        {
            //遍历集体活动库，找到id为s的集体活动，返回该集体活动的名称
            for (int i = 0; i < 1000; i++)
            {
                if (groupactivity[i] != null)
                    if (groupactivity[i].getId()!=-1 && groupactivity[i].getId()==id)
                        return groupactivity[i].getName();
            }
            return null;

        }
        else if (k==3)
        {
            //遍历个人活动库，找到id为s的个人活动，返回该个人活动的名称
            for (int i = 0; i < 1000; i++)
            {
                if (personalactivity[i] != null)
                    if (personalactivity[i].getId()!=-1 && personalactivity[i].getId()==id)
                        return personalactivity[i].getName();
            }
            return null;

        }


        return null;
    }

}
