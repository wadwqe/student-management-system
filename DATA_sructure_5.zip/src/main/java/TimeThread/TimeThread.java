package TimeThread;

import Stu.Student;
import TIME.Time;
public class TimeThread extends Thread {
    private boolean suspendFlag = false; // 控制线程的执行
    private Time now = new Time();
    private Student student;
    public void setSuspendFlag(boolean suspendFlag) {
        this.suspendFlag = suspendFlag;
    }
    public TimeThread(Student student)
    {
        this.student = student;
    }
    public void run() {
        while (true) {
//            if(isInterrupted())
//            {
//                break;
//            }
            try {
                Thread.sleep(3000);
                Time.addTime();
                System.out.println("now time: " + Time.getTime() + "(输入t暂停时间)");
                student.TimeDetection(now);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            synchronized (this) {
                while (suspendFlag) {
                    try {
                        System.out.println("当前时间已暂停");
                        this.wait(); // 暂停线程
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
