package Window;

import Stu.Student;
import TotalAffair.GroupActivity;
import TotalAffair.PersonalActivity;
import TotalAffair.TemporaryAffair;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

import static Window.Select_course.idToName;
import static Window.Student_windows.student_window;

public class Add_Affair {

    public static void Add_Affair_window(Student student){
        JFrame frame = new JFrame("添加事务界面");//创建一个窗口对象
        frame.setSize(1000, 910);//设置窗口的大小
        frame.setLocationRelativeTo(null);//设置窗口居中
        //设置窗口关闭的监听器
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                student_window(student);
            }
        });

        frame.setVisible(true);//设置窗口可见
        frame.setLayout(new BorderLayout());
        //设置窗口大小不可变
        frame.setResizable(false);


        JSplitPane splitPane = new JSplitPane();//用于分割窗口的组件
        splitPane.setDividerLocation(200);//设置分割线的位置
        splitPane.setDividerSize(8);//设置分割线的宽度
        //设置分割线不可拖动
        splitPane.setEnabled(false);
        frame.add(splitPane, BorderLayout.CENTER);//将分割面板添加到窗口中
        JPanel leftPanel = new JPanel();//左边面板
        JPanel rightPanel = new JPanel();//右边面板
        leftPanel.setVisible(true);
        rightPanel.setVisible(true);
        leftPanel.setLayout(null);
        rightPanel.setLayout(new BorderLayout());
        splitPane.setRightComponent(rightPanel);//将右边面板添加到分割面板中
        splitPane.setLeftComponent(leftPanel);//将左边面板添加到分割面板中

        String[] week = {"第一周", "第二周", "第三周", "第四周", "第五周", "第六周", "第七周", "第八周", "第九周", "第十周", "第十一周", "第十二周", "第十三周", "第十四周", "第十五周", "第十六周", "第十七周", "第十八周", "第十九周", "第二十周"};
        JComboBox<String> comboBox = new JComboBox<>(week);
        comboBox.setBounds(0, 0, 200, 50);
        comboBox.setVisible(true);
        //将下拉列表添加到右边面板的北边
//        JPanel UPpanel = new JPanel();
//        UPpanel.add(comboBox);
        rightPanel.add(comboBox, BorderLayout.NORTH);
        //新建一个面板，用于显示学生的课表
        JPanel tablePanel = new JPanel();
        //将表格面板添加到右边面板的中间
        //设置面板不可见
        tablePanel.setVisible(true);
        tablePanel.setLayout(new BorderLayout());

        rightPanel.add(tablePanel, BorderLayout.CENTER);

        JTable table = new JTable();

        //定义一个下拉列表，用于选择周数

        //获取下拉列表中的周数（Sring）,通过映射关系，获取到对应的周数(int),使用监视器，当下拉列表中的周数发生改变时，获取到对应的周数，然后将周数传入showTable(rightPanel, student, weekNum);方法中，用于显示学生的课表
        final int[] weekNum = {1};

        showTable(tablePanel, student, weekNum[0], table);
        comboBox.addItemListener(e -> //添加监视器，如果下拉列表中的周数发生改变，那么获取到对应的周数
        {
            String s = (String) comboBox.getSelectedItem();
            if (s != null) {
                switch (s) {
                    case "第一周" -> weekNum[0] = 1;
                    case "第二周" -> weekNum[0] = 2;
                    case "第三周" -> weekNum[0] = 3;
                    case "第四周" -> weekNum[0] = 4;
                    case "第五周" -> weekNum[0] = 5;
                    case "第六周" -> weekNum[0] = 6;
                    case "第七周" -> weekNum[0] = 7;
                    case "第八周" -> weekNum[0] = 8;
                    case "第九周" -> weekNum[0] = 9;
                    case "第十周" -> weekNum[0] = 10;
                    case "第十一周" -> weekNum[0] = 11;
                    case "第十二周" -> weekNum[0] = 12;
                    case "第十三周" -> weekNum[0] = 13;
                    case "第十四周" -> weekNum[0] = 14;
                    case "第十五周" -> weekNum[0] = 15;
                    case "第十六周" -> weekNum[0] = 16;
                    case "第十七周" -> weekNum[0] = 17;
                    case "第十八周" -> weekNum[0] = 18;
                    case "第十九周" -> weekNum[0] = 19;
                    case "第二十周" -> weekNum[0] = 20;
                }
            }
            //tablePanel.removeAll();
            showTable(tablePanel, student, weekNum[0], table);

        });

        //定义一个标签，用于显示“课程表”
        JLabel label = new JLabel("课程事务表");
        label.setBounds(0, 0, 200, 70);
        label.setFont(new Font("宋体", Font.BOLD, 25));
        //设置文字居中
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setVisible(true);
        //将标签添加到右边面板的北边
        leftPanel.add(label);
        
        //定义一个按钮，用于添加事务
        JButton button1 = new JButton("添加集体活动");
        JButton button2 = new JButton("添加个人事务");
        JButton button3 = new JButton("添加临时事务");
        JButton button4 = new JButton("退出登录");

        button1.setBounds(0, 70, 200, 210);
        button2.setBounds(0, 280, 200, 210);
        button3.setBounds(0, 490, 200, 210);
        button4.setBounds(0, 700, 200, 210);


        //添加按钮1的监视器
        button1.addActionListener(e -> {

                JTextField GroupName = new JTextField(20);
                JTextField GroupStarTime = new JTextField(20);
                JTextField GroupEndTime = new JTextField(20);
                JTextField GroupLocation = new JTextField(20);
                JTextField GroupCycle = new JTextField(20);
                JTextField GroupOnline = new JTextField(20);
                JTextField GroupOnlinePlatform = new JTextField(20);
                JTextField GroupOnlineLink = new JTextField(20);

                JPanel myPanel = new JPanel();//创建一个面板
                myPanel.add(new JLabel("集体活动名称:"));
                myPanel.add(GroupName);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动开始时间:"));
                myPanel.add(GroupStarTime);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动结束时间:"));
                myPanel.add(GroupEndTime);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动循环周数:"));
                myPanel.add(GroupCycle);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动地点:"));
                myPanel.add(GroupLocation);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动是否线上:"));
                myPanel.add(GroupOnline);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动线上平台:"));
                myPanel.add(GroupOnlinePlatform);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("集体活动线上链接:"));
                myPanel.add(GroupOnlineLink);
                myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
                int result = JOptionPane.showConfirmDialog(null, myPanel, "请输入集体活动信息", JOptionPane.OK_CANCEL_OPTION);//
                if (result == JOptionPane.OK_OPTION)
                {
                    String GroupNameString = GroupName.getText();
                    String GroupStarTimeString = GroupStarTime.getText();
                    int GroupStarTimeInt = Integer.parseInt(GroupStarTimeString);
                    String GroupEndTimeString = GroupEndTime.getText();
                    int GroupEndTimeInt = Integer.parseInt(GroupEndTimeString);
                    String GroupCycleString = GroupCycle.getText();
                    int GroupCycleInt = Integer.parseInt(GroupCycleString);
                    String GroupLocationString = GroupLocation.getText();
                    int GroupLocationInt = Integer.parseInt(GroupLocationString);
                    String GroupOnlineString = GroupOnline.getText();
                    boolean GroupOnlineBoolean = Boolean.parseBoolean(GroupOnlineString);
                    String GroupOnlinePlatformString = GroupOnlinePlatform.getText();
                    String GroupOnlineLinkString = GroupOnlineLink.getText();
                    //通过输入的信息，新建一个集体活动
                    GroupActivity groupActivity = new GroupActivity(GroupNameString, GroupStarTimeInt, GroupEndTimeInt,GroupCycleInt ,GroupLocationInt, GroupOnlineBoolean, GroupOnlinePlatformString, GroupOnlineLinkString);
                    student.addAffair(groupActivity);
                    showTable(tablePanel, student, weekNum[0], table);
                }

            
        });
        //添加按钮2的监视器
        button2.addActionListener(e -> {

                JTextField PersonalName = new JTextField(20);
                JTextField PersonalStarTime = new JTextField(20);
                JTextField PersonalEndTime = new JTextField(20);
                JTextField PersonalLocation = new JTextField(20);
                JTextField PersonalCycle = new JTextField(20);
                JTextField PersonalOnline = new JTextField(20);
                JTextField PersonalOnlinePlatform = new JTextField(20);
                JTextField PersonalOnlineLink = new JTextField(20);

                JPanel myPanel = new JPanel();//创建一个面板
                myPanel.add(new JLabel("个人事务名称:"));
                myPanel.add(PersonalName);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务开始时间:"));
                myPanel.add(PersonalStarTime);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务结束时间:"));
                myPanel.add(PersonalEndTime);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务循环周数:"));
                myPanel.add(PersonalCycle);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务地点:"));
                myPanel.add(PersonalLocation);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务是否线上:"));
                myPanel.add(PersonalOnline);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务线上平台:"));
                myPanel.add(PersonalOnlinePlatform);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("个人事务线上链接:"));
                myPanel.add(PersonalOnlineLink);
                myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
                int result = JOptionPane.showConfirmDialog(null, myPanel, "请输入个人事务信息", JOptionPane.OK_CANCEL_OPTION);//
                if (result == JOptionPane.OK_OPTION)
                {
                    String PersonalNameString = PersonalName.getText();
                    String PersonalStarTimeString = PersonalStarTime.getText();
                    int PersonalStarTimeInt = Integer.parseInt(PersonalStarTimeString);
                    String PersonalEndTimeString = PersonalEndTime.getText();
                    int PersonalEndTimeInt = Integer.parseInt(PersonalEndTimeString);
                    String PersonalCycleString = PersonalCycle.getText();
                    int PersonalCycleInt = Integer.parseInt(PersonalCycleString);
                    String PersonalLocationString = PersonalLocation.getText();
                    int PersonalLocationInt = Integer.parseInt(PersonalLocationString);
                    String PersonalOnlineString = PersonalOnline.getText();
                    boolean PersonalOnlineBoolean = Boolean.parseBoolean(PersonalOnlineString);
                    String PersonalOnlinePlatformString = PersonalOnlinePlatform.getText();
                    String PersonalOnlineLinkString = PersonalOnlineLink.getText();
                    //通过输入的信息，新建一个个人事务
                    PersonalActivity personalActivity = new PersonalActivity(PersonalNameString, PersonalStarTimeInt, PersonalEndTimeInt,PersonalCycleInt ,PersonalLocationInt, PersonalOnlineBoolean, PersonalOnlinePlatformString, PersonalOnlineLinkString);
                    student.addAffair(personalActivity);
                    showTable(tablePanel, student, weekNum[0], table);
                }

        });
        //添加按钮3的监视器，用于添加临时事务
        button3.addActionListener(e -> {

                JTextField TemporaryName = new JTextField(20);
                JTextField TemporaryStarTime = new JTextField(20);
                JTextField TemporaryEndTime = new JTextField(20);
                JTextField TemporaryLocation = new JTextField(20);

                JTextField TemporaryOnline = new JTextField(20);
                JTextField TemporaryOnlinePlatform = new JTextField(20);
                JTextField TemporaryOnlineLink = new JTextField(20);

                JPanel myPanel = new JPanel();//创建一个面板
                myPanel.add(new JLabel("临时事务名称:"));
                myPanel.add(TemporaryName);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("临时事务开始时间:"));
                myPanel.add(TemporaryStarTime);

                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("临时事务结束时间:"));
                myPanel.add(TemporaryEndTime);



                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("临时事务地点:"));
                myPanel.add(TemporaryLocation);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("临时事务是否线上:"));
                myPanel.add(TemporaryOnline);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("临时事务线上平台:"));
                myPanel.add(TemporaryOnlinePlatform);
                myPanel.add(Box.createHorizontalStrut(15)); // a spacer
                myPanel.add(new JLabel("临时事务线上链接:"));
                myPanel.add(TemporaryOnlineLink);
                myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
                int result = JOptionPane.showConfirmDialog(null, myPanel, "请输入临时事务信息", JOptionPane.OK_CANCEL_OPTION);//
                if (result == JOptionPane.OK_OPTION)
                {
                    String TemporaryNameString = TemporaryName.getText();
                    String TemporaryStarTimeString = TemporaryStarTime.getText();
                    int TemporaryStarTimeInt = Integer.parseInt(TemporaryStarTimeString);
                    String TemporaryEndTimeString = TemporaryEndTime.getText();
                    int TemporaryEndTimeInt = Integer.parseInt(TemporaryEndTimeString);

                    String TemporaryLocationString = TemporaryLocation.getText();
                    int TemporaryLocationInt = Integer.parseInt(TemporaryLocationString);
                    String TemporaryOnlineString = TemporaryOnline.getText();
                    boolean TemporaryOnlineBoolean = Boolean.parseBoolean(TemporaryOnlineString);
                    String TemporaryOnlinePlatformString = TemporaryOnlinePlatform.getText();
                    String TemporaryOnlineLinkString = TemporaryOnlineLink.getText();
                    //通过输入的信息，新建一个临时事务
                    TemporaryAffair TemporaryAffair = new TemporaryAffair(TemporaryNameString, TemporaryStarTimeInt, TemporaryEndTimeInt,TemporaryLocationInt, TemporaryOnlineBoolean, TemporaryOnlinePlatformString, TemporaryOnlineLinkString);
                    student.addAffair(TemporaryAffair);
                    showTable(tablePanel, student, weekNum[0], table);
                }

        });
        //添加按钮4的监视器，用于退出窗口返回上级菜单
        button4.addActionListener(e -> {
            frame.dispose();
            student_window(student);
        });
        
        button1.setVisible(true);
        button2.setVisible(true);
        button3.setVisible(true);
        button4.setVisible(true);

        leftPanel.add(button1);
        leftPanel.add(button2);
        leftPanel.add(button3);
        leftPanel.add(button4);



    }

    public static void showTable(JPanel tablePanel, Student student, int week1_int,JTable table) {
        //定义表头
        String[] columnNames = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};



        //定义一个二维数组，用于存储表格中的数据，//根据下拉列表中的周数，来考虑遍历什么地方的Ctime_table[]数组，因为一周有24*7=168个小时，所以如果week1=2，那么就遍历Ctime_table[168]到Ctime_table[335]，如果week1=3，那么就遍历Ctime_table[336]到Ctime_table[503]，以此类推
        String[][] data1 = new String[24][7];
        String[][] data2 = new String[10][7];
        String[][] data3 = new String[10][7];
        //初始化data1、data2数组为0
        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                data1[i][j] = "0";
                if (i >= 8 && i <= 17) {
                    data2[i - 8][j] = "0";
                    data3[i - 8][j] = "0";
                }
            }
        }


        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                if(!String.valueOf(student.getCtime_table()[i + j * 24 + (week1_int - 1) * 168]).equals("0"))
                {
                    data1[i][j] = String.valueOf(student.getCtime_table()[i + j * 24 + (week1_int - 1) * 168]);
                    if (i >= 8 && i <= 17) {
                    data2[i - 8][j] = data1[i][j];}
                }
            }
        }
        idToName(1, data2, data3);



        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                if (!String.valueOf(student.getGtime_table()[i + j * 24 + (week1_int - 1) * 168]).equals("0")) {
                    data1[i][j] = String.valueOf(student.getGtime_table()[i + j * 24 + (week1_int - 1) * 168]);
                    if (i >= 8 && i <= 17) {
                        data2[i - 8][j] = data1[i][j];
                    }
                }
            }
        }


        idToName(2, data2, data3);



        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                if (!String.valueOf(student.getPtime_table()[i + j * 24 + (week1_int - 1) * 168]).equals("0")){
                    data1[i][j] = String.valueOf(student.getPtime_table()[i + j * 24 + (week1_int - 1) * 168]);
                    if (i >= 8 && i <= 17) {
                        data2[i - 8][j] = data1[i][j];
                    }
                }
            }

        }
        idToName(3, data2, data3);

        /*for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 7; j++) {
                data1[i][j] = String.valueOf(student.getTtime_table()[i + j * 24 + (week1_int - 1) * 168]);
                if (i >= 8 && i <= 17) {
                    data2[i - 8][j] = data1[i][j];
                }
            }
        }*/

        //通过MAP映射，将data2数组中的0、1、2、3等课程id转换为对应的课程名称，映射到data3数组中

        //idToName(data2, data3);

        //课程表中连续时间段的同一课程的多个单元格合并为一个单元格
        //MerGeCell(table, data3);




        //打印data2数组，用于测试
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 7; j++) {
                System.out.print(data3[i][j] + " ");
            }
            System.out.println();
        }
        //打印“***************”
        System.out.println("***************");


        //设置表格的模式
        table.setModel(new DefaultTableModel(data3, columnNames));
        //设置表头大小
        table.getTableHeader().setPreferredSize(new Dimension(table.getTableHeader().getWidth(), 50));
        //

        table.setRowHeight(80);


        //tablePanel.removeAll();
        //设置可见性
        tablePanel.setVisible(true);




        //将表头和表格添加到右边面板中,表头在北边，表格填充剩余空间
        tablePanel.add(table.getTableHeader(), BorderLayout.NORTH);
        tablePanel.add(table, BorderLayout.CENTER);
        table.setVisible(true);
        //tablePanel.paintImmediately(tablePanel.getBounds());

    }


}
